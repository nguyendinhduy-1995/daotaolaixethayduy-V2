-- CreateIndex
CREATE INDEX "Lead_ownerId_createdAt_idx" ON "Lead"("ownerId", "createdAt");
