export { GET, PATCH } from "@/app/api/users/[id]/route";
