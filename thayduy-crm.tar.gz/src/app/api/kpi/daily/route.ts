import { NextResponse } from "next/server";
import { AuthError, requireAuth } from "@/lib/auth";
import { jsonError } from "@/lib/api-response";
import { getKpiDaily, KpiDateError, resolveKpiDateParam } from "@/lib/services/kpi-daily";

export async function GET(req: Request) {
  try {
    requireAuth(req);
  } catch (error) {
    if (error instanceof AuthError) {
      return jsonError(error.status, error.code, error.message);
    }
    return jsonError(401, "UNAUTHORIZED", "Unauthorized");
  }

  try {
    const { searchParams } = new URL(req.url);
    const date = resolveKpiDateParam(searchParams.get("date"));
    const kpi = await getKpiDaily(date);
    return NextResponse.json(kpi);
  } catch (error) {
    if (error instanceof KpiDateError) {
      return jsonError(400, "BAD_REQUEST", error.message);
    }
    return jsonError(500, "INTERNAL_ERROR", "Internal server error");
  }
}
