"use client";

export function Spinner() {
  return <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-zinc-300 border-t-slate-800" />;
}
